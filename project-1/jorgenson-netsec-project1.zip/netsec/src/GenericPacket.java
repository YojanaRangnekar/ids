
public class GenericPacket {
	
	public String packet_type;
	public boolean is_valid = false;

}//end GenericPacket
